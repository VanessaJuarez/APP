//
//  TireViewController.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/28/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class TireViewController: UIViewController {

    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var ed: UITextField!
    @IBOutlet weak var width: UITextField!
    @IBAction func next(_ sender: UIButton) {
        guard let idiameter = id.text,
            let ediameter = ed.text,
            let widtht = width.text else { return }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    


}
