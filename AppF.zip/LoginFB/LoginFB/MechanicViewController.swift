//
//  MechanicViewController.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/28/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class MechanicViewController: UIViewController {
   
    
    @IBOutlet weak var explain: UITextField!
    @IBAction func next(_ sender: UIButton) {
        guard let reason = explain.text
        else { return }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    


}
