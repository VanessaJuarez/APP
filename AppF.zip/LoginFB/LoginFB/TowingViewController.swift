//
//  TowingViewController.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/29/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class TowingViewController: UIViewController {
    
    var option = ""

    @IBAction func towingCrane(_ sender: UIButton) {
        option = "Towing Crane"
    }
    @IBAction func flatbedtowing(_ sender: UIButton) {
        option = "Flatbed Towing"
    }
    
    @IBAction func next(_ sender: UIButton) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    



}
