//
//  PaymentViewController.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/23/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class PaymentViewController: UIViewController {

    @IBAction func cash(_ sender: UIButton) {
        
    }
    
    @IBAction func card(_ sender: UIButton) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    



}
