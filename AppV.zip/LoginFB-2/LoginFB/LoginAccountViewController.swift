//
//  LoginAccountViewController.swift
//  LoginFB
//
//  Created by Germán Santos Jaimes on 11/7/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class LoginAccountViewController: UIViewController {

    
    @IBAction func mechanic(_ sender: UIButton) {
    }
    
    @IBAction func fuel(_ sender: UIButton) {
    }
    
    @IBAction func tire(_ sender: UIButton) {
    }
    
    @IBAction func battery(_ sender: UIButton) {
    }
    
    @IBAction func towing(_ sender: UIButton) {
    }
    
    @IBAction func location(_ sender: UIButton) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func logoutUser(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
}
