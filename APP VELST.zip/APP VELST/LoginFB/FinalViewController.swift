//
//  FinalViewController.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/29/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import MapKit

class FinalViewController: UIViewController {

    @IBOutlet weak var checkMap: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    


}
