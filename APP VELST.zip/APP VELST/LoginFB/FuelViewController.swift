//
//  FuelViewController.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/28/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class FuelViewController: UIViewController {
    
    var option = ""
    
    @IBOutlet weak var liters: UITextField!
    
    @IBAction func M(_ sender: UIButton) {
        option = "Magna"
    }
    @IBAction func P(_ sender: UIButton) {
        option = "Premium"
    }
    
    @IBAction func next(_ sender: UIButton) {
        guard let lts = liters.text
            else { return }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
