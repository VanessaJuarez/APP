//
//  TireViewController.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/28/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class TireViewController: UIViewController {

   
    @IBOutlet weak var intd: UITextField!
    @IBOutlet weak var extd: UITextField!
    @IBOutlet weak var width: UITextField!
    
    @IBAction func next(_ sender: UIButton) {
        guard let id = intd.text,
            let ed = extd.text,
            let width = width.text else { return }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    


}
