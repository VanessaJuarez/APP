//
//  CardInformationViewController.swift
//  LoginFB
//
//  Created by Usuario invitado on 11/28/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class CardInformationViewController: UIViewController {

    @IBOutlet weak var number: UITextField!
    @IBOutlet weak var sc: UITextField!
    @IBOutlet weak var expiration: UITextField!
    
    @IBAction func finish(_ sender: UIButton) {
        guard let numberCard = number.text,
            let securityCode = sc.text,
            let expirationDate = expiration.text else { return }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    


}
